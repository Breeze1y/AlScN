"""Reproduce the paired, forward-field vacancy sensitivity study."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import numpy as np

from fast_kmc import CachedFormingModel
from forming_iv import ElectronicConfig, electronic_network, run_forming
from kmc_model import Config
from morphology_metrics import metrics
from run import panel, plt
from run_forming import make_protocol, save_csv


VARIANTS = {'uncoupled': 0.0, 'vacancy_penalty': 0.05}
HOLD_SAMPLES = 5


def run_case(out, variant, config, electronics, protocol):
    start = time.perf_counter()
    prefix = out / f'{variant}_seed_{config.seed}'

    def progress(i, model, status):
        if i >= len(protocol) - HOLD_SAMPLES:
            print(f'{prefix.name} hold {i - len(protocol) + HOLD_SAMPLES + 1}/{HOLD_SAMPLES}: '
                  f't={model.time:.5f} s, N={model.steps}, {status}', flush=True)

    model, summary, scan_states, _ = run_forming(config, electronics, protocol, progress,
                                                 model_class=CachedFormingModel)
    state = scan_states[-1]
    geometry = metrics(state, config.spacing_nm, config.layer_cells)
    summary.update(variant=variant, morphology=geometry, trace=model.trace,
                   hop_layer_counts=model.hop_layer_counts.tolist(),
                   wall_s=time.perf_counter() - start)
    if summary['first_bridge']:
        first = next(record for record in model.iv if record['connected'])
        metal_only = electronic_network(state, config.spacing_nm,
                                        replace(electronics, max_tunnel_gap_nm=0))
        metal_current = metal_only['conductance_S'] * first['device_voltage_V']
        summary['bridge_readout'] = dict(current_A=first['current_A'],
                                        metal_only_current_A=metal_current,
                                        metal_only_fraction=metal_current / first['current_A'],
                                        compliance_active=first['compliance_active'])
    else:
        summary['bridge_readout'] = None
    save_csv(prefix.with_suffix('.iv.csv'), model.iv)
    np.savez_compressed(prefix.with_suffix('.npz'), snapshots=np.asarray(model.snapshots),
                        snapshot_times_s=[row['time_s'] for row in model.trace],
                        snapshot_events=[row['events'] for row in model.trace], scan_states=scan_states,
                        vacancy_mask=model.vacancy_mask.reshape(model.shape),
                        site_energy_eV=model.site.reshape(model.shape))
    prefix.with_suffix('.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(f'{prefix.name} finished: {summary["status"]}, {summary["wall_s"]:.1f} wall s', flush=True)
    return summary


def archive_comparison(out, summaries, seeds):
    fig, axes = plt.subplots(len(VARIANTS), len(seeds), squeeze=False,
                             figsize=(4.1 * len(seeds), 6.6), layout='constrained')
    rows = []
    for ax, summary in zip(axes.ravel(), summaries):
        config = Config(**summary['config'])
        variant = summary['variant']
        with np.load(out / f'{variant}_seed_{config.seed}.npz', allow_pickle=False) as data:
            state = data['scan_states'][-1]
            mask = data['vacancy_mask']
        bridge = summary['first_bridge'] or {}
        status = ('Ag bridge' if bridge else 'budget reached' if summary['status'] == 'event_budget_unknown'
                  else 'no bridge in protocol')
        panel(ax, state, config, f'{variant} | seed {config.seed}\n{status}, t={summary["morphology_time_s"]:.3f} s')
        z, x = np.nonzero(mask[1:-1] & (state[1:-1] == 0))
        ax.scatter((x + .5) * config.spacing_nm, (z + .5) * config.spacing_nm,
                   s=1.5, c='#7b8598', linewidths=0, alpha=.75)
        geometry = summary['morphology']
        residence = summary['ion_residence_s'][1]
        rows.append(dict(variant=variant, seed=config.seed, status=summary['status'],
                         events=summary['events'], morphology_time_s=summary['morphology_time_s'],
                         bridge_command_V=bridge.get('command_voltage_V'),
                         bridge_device_V=bridge.get('device_voltage_V'),
                         metal_only_fraction=(summary['bridge_readout'] or {}).get('metal_only_fraction'),
                         middle_vacancy_residence_fraction=(summary['vacancy_ion_residence_s'][1] / residence
                                                            if residence else None),
                         middle_metal=geometry['layer_metals'][1], metal_total=geometry['metal'],
                         bottleneck=geometry['vertex_bottleneck_4'],
                         missing_cells=geometry['minimum_missing_cells_4'],
                         ag_balance_error=summary['ag_balance_error']))
    fig.suptitle('Forward-field Ag forming | gold: Ag, teal: Ag+, dots: vacancy-affected host cells\n'
                 'Final morphology at first bridge or stop; exploratory model')
    fig.savefig(out / 'paired_morphology.png', dpi=175)
    plt.close(fig)
    save_csv(out / 'summary.csv', rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seeds', type=int, nargs='+', default=[7, 17, 27])
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()
    if args.workers < 1 or len(set(args.seeds)) != len(args.seeds) or min(args.seeds) < 0:
        parser.error('Use positive worker count and distinct nonnegative seeds')
    settings_path = ROOT / 'configs/forming_iv_fast_ramp.json'
    settings = json.loads(settings_path.read_text(encoding='utf-8'))
    model_path = ROOT / settings['model_config']
    config = replace(Config(**json.loads(model_path.read_text(encoding='utf-8'))),
                     disorder_seed=811, vacancy_seed=812,
                     vacancy_affected_fraction_by_layer=(0, .15, 0))
    electronics = ElectronicConfig(**settings['electronics'])
    protocol = make_protocol(settings['sweep'])
    hold = protocol.pop()
    protocol.extend([dict(hold, duration_s=hold['duration_s'] / HOLD_SAMPLES)] * HOLD_SAMPLES)

    out = ROOT / args.output
    out.mkdir(parents=True, exist_ok=False)
    sources = [Path(__file__), model_path, settings_path]
    sources += [ROOT / name for name in ['kmc_model.py', 'fast_kmc.py', 'forming_iv.py', 'run_forming.py',
                                         'run.py', 'morphology_metrics.py', 'requirements.txt']]
    manifest = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in sources}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (out / 'environment.json').write_text(json.dumps(dict(python=sys.version, dependencies={
        name: version(name) for name in ['numpy', 'scipy', 'matplotlib']}), indent=2), encoding='utf-8')
    with zipfile.ZipFile(out / 'source_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sources:
            archive.write(path, path.relative_to(ROOT).as_posix())

    cases = [(variant, seed, replace(config, seed=seed, vacancy_ag_ion_penalty_eV=penalty))
             for variant, penalty in VARIANTS.items() for seed in args.seeds]
    with ProcessPoolExecutor(max_workers=min(args.workers, len(cases))) as pool:
        jobs = {pool.submit(run_case, out, variant, cfg, electronics, protocol): (variant, seed)
                for variant, seed, cfg in cases}
        results = {jobs[job]: job.result() for job in as_completed(jobs)}
    summaries = [results[variant, seed] for variant, seed, _ in cases]
    (out / 'summary.json').write_text(json.dumps(summaries, indent=2), encoding='utf-8')
    archive_comparison(out, summaries, args.seeds)


if __name__ == '__main__':
    main()
