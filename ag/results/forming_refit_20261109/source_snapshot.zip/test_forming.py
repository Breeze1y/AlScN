"""Analytic electronic limits, compliance feedback, and scan stopping checks."""
from dataclasses import replace
import unittest
from unittest.mock import patch
import numpy as np
from kmc_model import Config
from forming_iv import ElectronicConfig, electronic_network, circuit_point, FormingModel, run_forming, leakage_current
from run_forming import make_protocol


class ElectronicTests(unittest.TestCase):
    def setUp(self):
        self.e = ElectronicConfig(leakage_per_column_S=0.)

    def test_straight_wire_and_parallel_wires_match_series_resistance(self):
        state = np.full((8,1),2,dtype=np.uint8)
        resistance = 7*self.e.metal_resistivity_ohm_m/(self.e.effective_depth_nm*1e-9)+2*self.e.contact_resistance_ohm
        one=electronic_network(state,1.,self.e)
        two=electronic_network(np.repeat(state,2,axis=1),1.,self.e)
        self.assertAlmostEqual(one['conductance_S'],1/resistance,places=12)
        self.assertAlmostEqual(two['conductance_S'],2/resistance,places=12)
        self.assertLess(one['kcl_residual_A_at_1V'],1e-12)

    def test_one_cell_tunneling_and_ions_do_not_make_metal_bridge(self):
        state = np.array([[2],[1],[2]],dtype=np.uint8)
        result = electronic_network(state,1.,self.e)
        expected=self.e.tunnel_prefactor_S*np.exp(-10.2463344)
        self.assertAlmostEqual(result['conductance_S']/expected,1.,places=10)
        self.assertEqual(result['tunnel_edges'],1)
        self.assertLess(result['conductance_S'],electronic_network(np.full((3,1),2),1.,self.e)['conductance_S'])
        state[1]=0
        self.assertEqual(result['conductance_S'],electronic_network(state,1.,self.e)['conductance_S'])

    def test_no_spurious_leak_from_floating_island_or_large_gap(self):
        state=np.zeros((12,5),np.uint8);state[[0,-1]]=2;state[6,2]=2
        self.assertEqual(electronic_network(state,1.,self.e)['conductance_S'],0.)

    def test_load_line_and_current_limit_are_voltage_feedback(self):
        e=replace(self.e,compliance_A=1e-3,series_resistance_ohm=100.)
        low=circuit_point(.5,.001,1,e)
        self.assertFalse(low['compliance_active'])
        self.assertAlmostEqual(low['current_A'],.5/1100.,places=12)
        high=circuit_point(3.,.001,1,e)
        self.assertTrue(high['compliance_active'])
        self.assertAlmostEqual(high['current_A'],.001,places=12)
        self.assertAlmostEqual(high['device_voltage_V'],1.,places=12)
        self.assertLess(high['source_delivered_voltage_V'],high['command_voltage_V'])
        reverse=circuit_point(-3.,.001,1,e)
        self.assertAlmostEqual(reverse['current_A'],-high['current_A'],places=12)
        self.assertAlmostEqual(circuit_point(0,.001,1,e)['current_A'],0.,places=12)

    def test_nonlinear_leakage_is_additive_and_limited(self):
        e=replace(self.e,leakage_per_column_S=1e-3)
        p=circuit_point(3,0,2,e)
        self.assertTrue(p['compliance_active'])
        self.assertAlmostEqual(p['current_A'],p['leakage_current_A'],places=12)
        self.assertAlmostEqual(p['current_A'],e.compliance_A,places=12)

    def test_model_receives_reduced_device_voltage(self):
        m=FormingModel(Config(nx=2,layer_cells=2,voltage=3),self.e)
        m.state.reshape(m.shape)[1:-1,0]=2
        m.net_source=6
        m.update_structure()
        self.assertTrue(m.connected)
        self.assertTrue(m.operating['compliance_active'])
        self.assertLess(m.c.voltage,3.)
        self.assertEqual(m.c.voltage,m.operating['device_voltage_V'])
        before=m.state.copy();m.apply_command(2.8)
        np.testing.assert_array_equal(m.state,before)

    def test_prebridge_compliance_changes_electrostatic_boundary(self):
        e=replace(self.e,leakage_per_column_S=1e-3)
        m=FormingModel(Config(nx=2,layer_cells=2,voltage=3),e)
        self.assertFalse(m.connected)
        self.assertTrue(m.operating['compliance_active'])
        self.assertLess(m.c.voltage,3.)
        np.testing.assert_allclose(m.phi.reshape(m.shape)[0],m.c.voltage,atol=1e-12)
        self.assertAlmostEqual(m.operating['current_A'],e.compliance_A,places=12)
        with self.assertRaises(NotImplementedError):m.save_checkpoint('unused.npz')
        with self.assertRaises(NotImplementedError):FormingModel.load_checkpoint('unused.npz')

    def test_saturation_and_network_parallel_scale(self):
        e=replace(self.e,leakage_model='saturating_power',leakage_saturation_A=2e-6,
                  leakage_half_voltage_V=.5,leakage_exponent=2)
        self.assertAlmostEqual(leakage_current(.5,150,e),1e-6,places=15)
        self.assertAlmostEqual(leakage_current(-.5,150,e),-1e-6,places=15)
        self.assertEqual(leakage_current(0,150,e),0.)
        self.assertLess(leakage_current(100,150,e),2e-6)
        wire=np.full((8,1),2)
        g=electronic_network(wire,1,e)['conductance_S']
        self.assertAlmostEqual(electronic_network(wire,1,replace(e,network_parallel_factor=10))['conductance_S'],10*g,places=12)


class ScanTests(unittest.TestCase):
    def test_bridge_freezes_morphology_but_completes_readout_time(self):
        c=Config(nx=2,layer_cells=2,max_time_s=.1)
        def bridge(m,deadline):
            m.state.reshape(m.shape)[1:-1,0]=2
            m.net_source=6;m.steps=1;m.time=.001
            m.update_structure();m.save()
            return m.result('first_bridge')
        with patch.object(FormingModel,'advance',bridge):
            m,s,states,records=run_forming(c,ElectronicConfig(),
                [dict(voltage_V=2.5,duration_s=.01),dict(voltage_V=3,duration_s=.01),
                 dict(voltage_V=0,duration_s=.01)],allow_frozen_return=True)
        self.assertEqual(s['status'],'first_bridge_frozen_readout')
        self.assertEqual(s['events'],1)
        self.assertEqual(s['morphology_time_s'],.001)
        self.assertEqual(s['scan_end_time_s'],.03)
        np.testing.assert_array_equal(states[0],states[1])
        np.testing.assert_array_equal(states[0],states[2])
        self.assertEqual(m.iv[-1]['current_A'],0.)
        self.assertTrue(all(r['kind']=='frozen_bridge_readout' for r in m.iv if r['time_s']>.001))

    def test_event_budget_stops_without_fabricating_remaining_scan(self):
        c=Config(nx=8,layer_cells=4,max_events=1,max_time_s=.1,polarization_C_m2=0)
        protocol=[dict(voltage_V=.8,duration_s=.05),dict(voltage_V=1.,duration_s=.05)]
        m,s,states,records=run_forming(c,ElectronicConfig(),protocol)
        self.assertEqual(s['status'],'event_budget_unknown')
        self.assertEqual(s['events'],1)
        self.assertEqual(len(states),1)
        self.assertLess(s['scan_end_time_s'],.05)
        self.assertEqual(s['ag_balance_error'],0)
        self.assertTrue(all(r['command_voltage_V']==.8 for r in m.iv))

    def test_protocol_rejects_reset_and_excess_duration(self):
        c=Config(nx=2,layer_cells=2,max_time_s=.1)
        for p in [[dict(voltage_V=1,duration_s=.01),dict(voltage_V=0,duration_s=.01)],
                  [dict(voltage_V=1,duration_s=.2)]]:
            with self.assertRaises(ValueError):run_forming(c,ElectronicConfig(),p)

    def test_positive_return_requires_bridge_and_never_runs_reset(self):
        c=Config(nx=2,layer_cells=2,max_time_s=.1)
        p=[dict(voltage_V=0,duration_s=.001),dict(voltage_V=.1,duration_s=.001),dict(voltage_V=0,duration_s=.001)]
        m,s,states,records=run_forming(c,ElectronicConfig(),p,allow_frozen_return=True)
        self.assertEqual(s['status'],'return_not_read_no_bridge')
        self.assertEqual(len(states),2)
        with self.assertRaises(ValueError):run_forming(c,ElectronicConfig(),
            [dict(voltage_V=1,duration_s=.001),dict(voltage_V=-1,duration_s=.001)],allow_frozen_return=True)

    def test_sweep_includes_endpoint_without_overshoot(self):
        p=make_protocol(dict(start_voltage_V=0,stop_voltage_V=1,step_voltage_V=.3,dwell_s=.01))
        self.assertEqual(p[-1]['voltage_V'],1.)
        self.assertTrue(all(0<=s['voltage_V']<=1 for s in p))


if __name__=='__main__':unittest.main()
