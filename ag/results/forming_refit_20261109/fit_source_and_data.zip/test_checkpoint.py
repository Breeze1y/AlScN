"""Pathwise continuation and segment-boundary checks, not fit-to-experiment tests."""
from dataclasses import replace
from pathlib import Path
import importlib.util
import json
import sys
import tempfile
import unittest
import zipfile
import numpy as np
from kmc_model import Config, Model


class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.cfg=Config(nx=8,layer_cells=4,voltage=.8,polarization_C_m2=0,
                        record_events=True,max_events=3000,max_time_s=.05,seed=18)

    def same_path(self,a,b):
        np.testing.assert_array_equal(a.state,b.state)
        np.testing.assert_array_equal(a.site,b.site)
        np.testing.assert_array_equal(a.phi,b.phi)
        self.assertEqual(a.event_log,b.event_log)
        self.assertEqual(a.rng.bit_generator.state,b.rng.bit_generator.state)
        self.assertEqual(a.pending_event,b.pending_event)
        self.assertEqual(a.counts,b.counts)
        self.assertEqual(a.time,b.time)
        np.testing.assert_array_equal(a.hop_layer_counts,b.hop_layer_counts)
        np.testing.assert_array_equal(a.net_deposition,b.net_deposition)
        np.testing.assert_allclose(a.ion_residence_s,b.ion_residence_s,rtol=1e-13,atol=1e-15)
        np.testing.assert_array_equal(a.vacancy_mask,b.vacancy_mask)
        np.testing.assert_allclose(a.vacancy_ion_residence_s,b.vacancy_ion_residence_s,rtol=1e-13,atol=1e-15)

    def test_pause_inside_waiting_time_preserves_exact_event_path(self):
        whole=Model(self.cfg);whole.run()
        split=Model(self.cfg)
        for time in [1e-6,.01,.017]: split.advance(time)
        self.assertIsNotNone(split.pending_event)
        with tempfile.TemporaryDirectory() as folder:
            path=split.save_checkpoint(Path(folder)/'state.npz')
            loaded=Model.load_checkpoint(path);loaded.run()
        self.same_path(whole,loaded)

    def test_event_budget_resume_and_changed_voltage_protocol(self):
        cfg=replace(self.cfg,vacancy_affected_fraction_by_layer=(.25,.5,.25),
                    vacancy_ag_ion_penalty_eV=.05,vacancy_seed=45)
        segments=[dict(voltage_V=v,duration_s=.01) for v in [.8,0,-.6,.5]]
        whole=Model(cfg);whole.run_protocol(segments,max_events=3000)
        self.assertGreater(whole.vacancy_ion_residence_s.sum(),0)
        split=Model(cfg);result=split.run_protocol(segments,max_events=1)
        self.assertEqual(result['status'],'event_budget_unknown')
        with tempfile.TemporaryDirectory() as folder:
            path=split.save_checkpoint(Path(folder)/'state.npz')
            loaded=Model.load_checkpoint(path)
            loaded.run_protocol(segments,max_events=3000)
        self.same_path(whole,loaded)
        self.assertEqual(whole.protocol_position,loaded.protocol_position)

    def test_corruption_rejected_and_no_implicit_overwrite(self):
        model=Model(self.cfg)
        with tempfile.TemporaryDirectory() as folder:
            path=model.save_checkpoint(Path(folder)/'state.npz')
            with self.assertRaises(FileExistsError): model.save_checkpoint(path)
            with np.load(path,allow_pickle=False) as data: fields={k:data[k].copy() for k in data.files}
            fields['site'][10]+=.1
            bad=Path(folder)/'bad.npz';np.savez_compressed(bad,**fields)
            with self.assertRaisesRegex(ValueError,'checksum'): Model.load_checkpoint(bad)

    def test_disorder_seed_is_independent_of_event_seed(self):
        a=Model(replace(self.cfg,disorder_seed=101,seed=1))
        b=Model(replace(self.cfg,disorder_seed=101,seed=2))
        np.testing.assert_array_equal(a.site,b.site)
        self.assertNotEqual(a.rng.bit_generator.state,b.rng.bit_generator.state)

    def test_preboundary_path_matches_frozen_v0(self):
        # Compare against the archived implementation, not a copy of new logic.
        archive=Path(__file__).parent/'results/seed7/source_snapshot.zip'
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'legacy_v0.py'
            with zipfile.ZipFile(archive) as z: source.write_bytes(z.read('kmc_model.py'))
            spec=importlib.util.spec_from_file_location('legacy_v0_reference',source)
            legacy=importlib.util.module_from_spec(spec);sys.modules[spec.name]=legacy;spec.loader.exec_module(legacy)
            cfg=dict(nx=8,layer_cells=4,voltage=.8,polarization_C_m2=0,max_events=1500,max_time_s=.05,seed=18)
            old=legacy.Model(legacy.Config(**cfg));old.run()
            new=Model(Config(**cfg,surface_redox_only=False));new.run()
            np.testing.assert_array_equal(old.state,new.state)
            self.assertEqual(old.counts,new.counts)
            self.assertEqual(old.time,new.time)
            sys.modules.pop(spec.name,None)


if __name__=='__main__': unittest.main()
