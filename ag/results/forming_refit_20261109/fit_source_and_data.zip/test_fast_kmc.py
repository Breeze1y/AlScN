"""Caching must preserve full random trajectories, not merely means."""
from dataclasses import replace
import unittest
import numpy as np
from kmc_model import Config, Model
from forming_iv import FormingModel, ElectronicConfig
from fast_kmc import CachedModel,CachedFormingModel


class CacheTests(unittest.TestCase):
    def compare(self,a,b):
        np.testing.assert_array_equal(a.state,b.state)
        np.testing.assert_array_equal(a.phi,b.phi)
        self.assertEqual(a.time,b.time)
        self.assertEqual(a.event_log,b.event_log)
        self.assertEqual(a.counts,b.counts)
        self.assertEqual(a.pending_event,b.pending_event)
        self.assertEqual(a.rng.bit_generator.state,b.rng.bit_generator.state)

    def test_changed_bias_and_moving_ions_keep_exact_path(self):
        cfg=Config(nx=8,layer_cells=4,max_events=4000,max_time_s=.1,seed=18,record_events=True,
                   vacancy_affected_fraction_by_layer=(.1,.5,.1),vacancy_ag_ion_penalty_eV=.05)
        a,b=Model(cfg),CachedModel(cfg)
        for voltage,time in [(0,.005),(.8,.02),(1.5,.04),(.3,.08)]:
            for m in [a,b]:m.set_voltage(voltage);m.advance(time)
            self.compare(a,b)
            np.testing.assert_array_equal(a.vacancy_ion_residence_s,b.vacancy_ion_residence_s)

    def test_circuit_feedback_and_neutral_migration_keep_exact_path(self):
        cfg=Config(nx=5,layer_cells=2,max_events=2000,max_time_s=.05,seed=7,
                   record_events=True,migration_eV=.5,voltage=.8)
        e=ElectronicConfig(leakage_per_column_S=1e-4,compliance_A=1e-5)
        a,b=FormingModel(cfg,e),CachedFormingModel(cfg,e)
        for voltage,time in [(.8,.01),(1.2,.03),(2.,.05)]:
            for m in [a,b]:m.apply_command(voltage);m.advance(time)
            self.compare(a,b)
            self.assertEqual(a.iv,b.iv)

    def test_all_channels_match_on_mixed_states_and_after_ion_motion(self):
        cfg=Config(nx=8,layer_cells=4,voltage=1.2,migration_eV=.5)
        a,b=Model(cfg),CachedModel(cfg)
        rng=np.random.default_rng(912)
        state=rng.choice([0,1,2],size=(12,8),p=[.65,.2,.15]).astype(np.uint8)
        for m in [a,b]:m.state.reshape(m.shape)[1:-1]=state;m.update_structure()
        def same_catalogue():
            aa,bb=a.catalogue(),b.catalogue()
            self.assertEqual([r[0] for r in aa],[r[0] for r in bb])
            self.assertIn('migrate',[r[0] for r in aa])
            for ga,gb in zip(aa,bb):
                for x,y in zip(ga[1:],gb[1:]):np.testing.assert_array_equal(x,y)
        same_catalogue()
        ion=int(np.flatnonzero(a.state==1)[0]);host=int(np.flatnonzero(a.interior&(a.state==0))[0])
        for m in [a,b]:m.state[ion]=0;m.state[host]=1
        same_catalogue()
        for m in [a,b]:m.c=replace(m.c,temperature_K=310)
        same_catalogue()


if __name__=='__main__':unittest.main()
