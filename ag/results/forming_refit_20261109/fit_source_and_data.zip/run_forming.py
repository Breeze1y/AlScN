"""Run and archive an exploratory forming scan with a current compliance."""
import argparse, csv, hashlib, json, platform, sys, time, zipfile
from pathlib import Path
from dataclasses import asdict, replace
from importlib.metadata import version
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from kmc_model import Config
from forming_iv import ElectronicConfig, run_forming
from run import panel

ROOT = Path(__file__).resolve().parent


def make_protocol(sweep):
    start, stop, step = (float(sweep[k]) for k in ['start_voltage_V','stop_voltage_V','step_voltage_V'])
    dwell, hold = float(sweep['dwell_s']), float(sweep.get('final_hold_s',0))
    if not all(np.isfinite(v) for v in [start,stop,step,dwell,hold]) or start<0 or stop<start or step<=0 or dwell<=0 or hold<0:
        raise ValueError('Invalid voltage sweep')
    voltages = list(np.arange(start, stop+step*1e-8, step))
    if not np.isclose(voltages[-1],stop): voltages.append(stop)
    else: voltages[-1]=stop
    protocol = [dict(voltage_V=float(v),duration_s=dwell) for v in voltages]
    if hold: protocol.append(dict(voltage_V=stop,duration_s=hold))
    return protocol


def save_csv(path, records):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,list(records[0]));writer.writeheader();writer.writerows(records)


def render(out, collected, electronics):
    fig, axes = plt.subplots(1,3,figsize=(18,5),layout='constrained')
    for prefix, m, summary in collected:
        data=m.iv
        command=np.array([r['command_voltage_V'] for r in data])
        current=np.abs([r['current_A'] for r in data])
        nonzero=current>0
        label=f"{summary['variant']} seed {summary['config']['seed']}"
        axes[0].semilogy(command[nonzero],current[nonzero],'.-',ms=2,lw=.8,label=label)
        actual=np.array([r['device_voltage_V'] for r in data])
        axes[1].semilogy(actual[nonzero],current[nonzero],'.-',ms=2,lw=.8,label=label)
        axes[2].plot(command,current*1e3,'.-',ms=2,lw=.8,label=label)
        bridge=summary['first_bridge']
        if bridge:
            row=next(r for r in data if r['connected'])
            axes[0].plot(row['command_voltage_V'],abs(row['current_A']),'*',ms=11)
        states=np.array(m.snapshots)
        records=m.trace
        metals=np.array([r['metal'] for r in records])
        ids=np.unique([0,*[int(np.argmin(abs(metals-v))) for v in np.linspace(0,metals[-1],6)],len(states)-1])
        if len(ids)>6: ids=ids[np.linspace(0,len(ids)-1,6).round().astype(int)]
        readings={(r['time_s'],r['events']):r for r in data if r['kind']!='frozen_bridge_readout'}
        evo, aa=plt.subplots(2,3,figsize=(15,8),layout='constrained')
        for ax in aa.ravel(): ax.set_visible(False)
        for ax,i in zip(aa.ravel(),ids):
            ax.set_visible(True)
            row=readings[(records[i]['time_s'],records[i]['events'])]
            panel(ax,states[i],m.c,
                  f"Vcmd={row['command_voltage_V']:.2f} V, Vdev={row['device_voltage_V']:.3g} V\n"
                  f"t={row['time_s']:.4g} s, I={row['current_A']:.3g} A, N={row['events']}")
            ax.set_xticks(np.linspace(0,m.c.nx*m.c.spacing_nm,4))
            ax.title.set_fontsize(10)
        evo.suptitle(f'{label} | actual growth frames, selected by Ag occupancy | frozen after first bridge')
        evo.savefig(prefix.parent/f'{prefix.name}_evolution.png',dpi=170)
        evo.savefig(prefix.parent/f'{prefix.name}_evolution.svg');plt.close(evo)
        detail,aa=plt.subplots(2,1,figsize=(10,7),layout='constrained')
        times=[r['time_s'] for r in data]
        aa[0].plot(times,command,label='Source command')
        aa[0].plot(times,[r['device_voltage_V'] for r in data],label='Actual device')
        aa[0].set(ylabel='Voltage (V)');aa[0].legend()
        aa[1].semilogy(times,np.maximum(current,1e-18),label='Total current')
        aa[1].axhline(electronics.compliance_A,color='red',ls='--',label='Compliance')
        aa[1].set(xlabel='Scan time (s)',ylabel='Current (A)');aa[1].legend()
        detail.suptitle(f'{label} | source command and device-voltage feedback')
        detail.savefig(prefix.parent/f'{prefix.name}_feedback.png',dpi=160);plt.close(detail)
    for ax in axes:
        ax.set_xlabel('Source command voltage (V)');ax.grid(alpha=.25);ax.legend(fontsize=8)
    axes[0].axhline(electronics.compliance_A,color='red',ls='--',lw=1)
    axes[0].set_ylabel('|Current| (A)')
    axes[1].axhline(electronics.compliance_A,color='red',ls='--',lw=1)
    axes[1].set(xlabel='Actual device voltage (V)',ylabel='|Current| (A)')
    axes[2].axhline(electronics.compliance_A*1e3,color='red',ls='--',lw=1)
    axes[2].set_ylabel('|Current| (mA)')
    fit_label='single-record fit candidate' if any('single_trace' in s['calibration_status'] for _,_,s in collected) else 'exploratory, uncalibrated'
    fig.suptitle(f'Single-forming I-V | {fit_label} | post-bridge morphology frozen')
    fig.savefig(out/'forming_iv.png',dpi=180);fig.savefig(out/'forming_iv.svg');plt.close(fig)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--config',default='configs/forming_iv.json')
    ap.add_argument('--output',required=True)
    ap.add_argument('--seeds',default='7')
    ap.add_argument('--controls',action='store_true')
    args=ap.parse_args()
    settings=json.loads((ROOT/args.config).read_text(encoding='utf-8'))
    cfg=Config(**json.loads((ROOT/settings['model_config']).read_text(encoding='utf-8')))
    electronics=ElectronicConfig(**settings.get('electronics',{}))
    protocol=settings.get('protocol') or make_protocol(settings['sweep'])
    out=ROOT/args.output;out.mkdir(parents=True,exist_ok=False)
    sources=[ROOT/n for n in ['kmc_model.py','forming_iv.py','run_forming.py','run.py','requirements.txt',args.config,settings['model_config']]]
    sources+=sorted(ROOT.glob('test_*.py'))
    if settings.get('event_catalogue')=='cached_exact':sources.append(ROOT/'fast_kmc.py')
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    with zipfile.ZipFile(out/'source_snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,str(p.relative_to(ROOT)))
    (out/'environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),
        dependencies={n:version(n) for n in ['numpy','scipy','matplotlib']}),indent=2),encoding='utf-8')
    variants=[('assist',cfg.polarization_C_m2)]
    if args.controls:variants += [('off',0.),('oppose',-cfg.polarization_C_m2)]
    collected=[]
    for variant,p in variants:
        for seed in map(int,args.seeds.split(',')):
            start=time.perf_counter()
            def progress(i,m,status):
                print(f'{variant} seed {seed} segment {i}: Vcmd={m.command_voltage:.3g}, '
                      f'Vdev={m.c.voltage:.3g}, N={m.steps}, t={m.time:.4g}, '
                      f'I={m.operating["current_A"]:.4g}, {status}',flush=True)
            cls=None
            if settings.get('event_catalogue')=='cached_exact':
                from fast_kmc import CachedFormingModel
                cls=CachedFormingModel
            m,summary,states,records=run_forming(replace(cfg,seed=seed,polarization_C_m2=p),electronics,protocol,progress,
                allow_frozen_return=settings.get('allow_frozen_return',False),model_class=cls)
            summary.update(variant=variant,wall_s=time.perf_counter()-start)
            summary['calibration_status']=settings.get('calibration_status',summary['calibration_status'])
            prefix=out/f'{variant}_seed_{seed}'
            prefix.with_suffix('.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
            prefix.with_suffix('.scan.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
            save_csv(prefix.with_suffix('.iv.csv'),m.iv)
            np.savez_compressed(prefix.with_suffix('.npz'),snapshots=np.array(m.snapshots),
                                snapshot_times_s=[r['time_s'] for r in m.trace],
                                snapshot_events=[r['events'] for r in m.trace],scan_states=states,
                                vacancy_mask=m.vacancy_mask.reshape(m.shape),
                                site_energy_eV=m.site.reshape(m.shape))
            collected.append((prefix,m,summary))
    render(out,collected,electronics)
    summaries=[s for _,_,s in collected]
    (out/'summary.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
    lines=['# 单次forming I–V演示','',f'{cfg.nx*cfg.spacing_nm:g} nm宽、{3*cfg.layer_cells*cfg.spacing_nm:g} nm厚；模型和电子参数均为探索值，尚未实验标定。',
           '电压采用分段恒定扫描，记录源指令电压和器件实际电压；发生限流时降低器件电压并反馈给后续KMC。启用正压回扫时仅允许成桥后固定形貌电路读出，不是RESET动力学。',
           '首次成桥后固定形貌继续读取电流，不模拟成桥后加厚、热效应、SET/RESET或电容瞬态。',
           '贯通前仍沿用原介电静电近似：电极连通金属视为等势，忽略离子空间电荷；电阻网络不是已完成标定的自洽电子输运模型。',
           '漏电是经验背景支路，可选sinh或饱和幂函数；网络并联倍率是有效电流窗口权重，不是实测细丝根数。隧穿仅包含沿网格轴线、指定距离内的金属间隙，不含陷阱辅助输运或三维路径。1 nm面外有效深度并非实验电极面积。',
           '左、右图横坐标为源指令电压，中图为器件实际电压。电流跳变可能发生在同一电压台阶的等待过程中；CSV的时间列保留这一信息。连线仅帮助阅读，不代表额外求解的中间状态。', '',
           '|条件|种子|状态|首次成桥事件|成桥源电压/V|守恒误差|','|---|---:|---|---:|---:|---:|']
    for prefix,m,s in collected:
        bridge=s['first_bridge'] or {}
        lines.append(f"|{s['variant']}|{s['config']['seed']}|{s['status']}|{bridge.get('events','—')}|{bridge.get('command_voltage_V','—')}|{s['ag_balance_error']}|")
    lines+=['','![forming I–V](forming_iv.png)','','电子参数与扫描设置详见各JSON；完整逐次金属结构变化的电流记录在*.iv.csv中。',
            '参考方法：[ECM形貌、隧穿与I–V的KMC研究](https://pubs.rsc.org/en/content/articlehtml/2015/nr/c5nr02258d)。这里只借鉴建模分层思路，没有移用其材料参数或声称复现论文。']
    (out/'运行报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(summaries,indent=2),flush=True)


if __name__=='__main__':main()
