import unittest
import numpy as np
from morphology_metrics import metrics
from kmc_model import Config,Model


class MorphologyTests(unittest.TestCase):
    def test_straight_broken_and_parallel_paths(self):
        state=np.zeros((8,7),np.uint8);state[[0,-1]]=2;state[:,2]=2
        r=metrics(state,1,2)
        self.assertEqual(r['path_tortuosity'],1)
        self.assertEqual(r['vertex_bottleneck_4'],1)
        self.assertEqual(r['skeleton_endpoints_8'],2)
        state[:,5]=2
        self.assertEqual(metrics(state,1,2)['vertex_bottleneck_4'],2)
        state[3,[2,5]]=0
        r=metrics(state,1,2)
        self.assertFalse(r['connected_4'])
        self.assertEqual(r['minimum_missing_cells_4'],1)

    def test_diagonal_is_not_a_four_neighbor_bridge(self):
        state=np.zeros((5,5),np.uint8);state[[0,-1]]=2
        for i in range(1,4):state[i,i]=2
        self.assertFalse(metrics(state,1,1)['connected_4'])

    def test_layer_flux_ledger_matches_event_log(self):
        m=Model(Config(nx=8,layer_cells=4,voltage=.8,polarization_C_m2=0,
                       record_events=True,max_events=1500,max_time_s=.05,seed=18))
        m.run();hops=np.zeros((3,3),int);deposition=np.zeros(3,int)
        for e in m.event_log:
            if e['kind']=='hop':hops[m.zone[e['a']],m.zone[e['b']]]+=1
            if e['kind']=='reduce':deposition[m.zone[e['a']]]+=1
            if e['kind']=='oxidize':deposition[m.zone[e['a']]]-=1
        np.testing.assert_array_equal(hops,m.hop_layer_counts)
        np.testing.assert_array_equal(deposition,m.net_deposition)
        self.assertEqual(hops.sum(),m.counts['hop'])
        self.assertEqual(deposition.sum(),np.sum((m.state==2)&m.interior))
        self.assertTrue((m.ion_residence_s>=0).all())


if __name__=='__main__':unittest.main()
