"""Audit the complete refit, preserving numerical and calibration distinctions."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',default='results/forming_refit_20261109')
    args=ap.parse_args();out=ROOT/args.results
    meta=json.loads((out/'passive_fit.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((ROOT/meta['source']).read_bytes()).hexdigest()==meta['sha256']
    archives=0
    for manifest_path in sorted(out.rglob('manifest.json')):
        manifest=json.loads(manifest_path.read_text())
        with zipfile.ZipFile(manifest_path.parent/'source_snapshot.zip') as z:
            for name,digest in manifest.items():
                assert hashlib.sha256(z.read(name.replace('\\','/'))).hexdigest()==digest
        archives+=1
    final_manifest=json.loads((out/'fit_source_manifest.json').read_text())
    with zipfile.ZipFile(out/'fit_source_and_data.zip') as z:
        for name,digest in final_manifest.items():
            assert hashlib.sha256(z.read(name)).hexdigest()==digest
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    scouts=[]
    for p in sorted((out/'scout').glob('*/*/summary.json')):
        s=json.loads(p.read_text());c=s['config']
        assert c['polarization_C_m2']==-.004
        assert c['vacancy_ag_ion_penalty_eV']==.05
        assert c['vacancy_affected_fraction_by_layer']==[0,.15,0]
        assert s['ag_balance_error']==0
        assert s['events']==sum(s['counts'].values())
        with np.load(p.parent/'states.npz') as data:
            assert np.all(data['snapshots'][0,1:-1]==0)
            assert np.count_nonzero(data['state'][1:-1])==s['counts']['inject']-s['counts']['absorb']
            assert not data['vacancy_mask'][[0,-1]].any()
        if s['status']=='event_budget_unknown':assert s['events']==c['max_events']
        elif s['bridge'] is None:assert abs(s['time_s']-1.01)<1e-12
        scouts.append(dict(path=p.parent.relative_to(ROOT).as_posix(),status=s['status'],events=s['events']))
    coupled=[]
    for p in sorted((out/'coupled').glob('*/*/summary.json')):
        process=subprocess.run([sys.executable,str(ROOT/'scripts/verify_forming.py'),
                  '--results',str(p.parent)],cwd=ROOT,capture_output=True,text=True)
        if process.returncode:
            raise RuntimeError(f'{p.parent}: {process.stdout}\n{process.stderr}')
        checks=json.loads((p.parent/'verification.json').read_text())
        coupled.append(dict(path=p.parent.relative_to(ROOT).as_posix(),**checks))
    fit=json.loads((out/'fit_metrics.json').read_text())
    assert fit['workflow_completed']
    training=[r for r in fit['runs'] if r['role']=='training']
    assert len(training)==3 and all(r['scout_exact_match'] for r in training)
    assert all(r['recorded_points']==202 for r in training)
    assert all(r['metal_only_fraction_at_bridge']>.99 for r in fit['runs'] if r['forming_voltage_V'] is not None)
    result=dict(numerical_audit_passed=True,measurement_unchanged=True,
                source_archives_checked=archives+1,final_sources_match_workspace=True,
                scouts=scouts,coupled=coupled,training_scout_exact_match=True,
                calibration_roles=fit['roles'],
                scope='Numerical integrity verified; phase-specific fit errors and limitations remain explicit')
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(numerical_audit_passed=True,scouts=len(scouts),coupled=len(coupled),
                         archives=archives+1),indent=2))


if __name__=='__main__':main()
