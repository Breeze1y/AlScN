"""Fit passive branches, select an ensemble and report the vacancy-enabled refit."""
from dataclasses import asdict, replace
from pathlib import Path
import argparse
import csv
import hashlib
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import numpy as np
from scipy.optimize import least_squares
from forming_iv import ElectronicConfig, electronic_network, leakage_current
from scripts.fit_forming import load_measurement
from scripts.refit_forming import write_json


def passive_fit(out):
    meta=json.loads((out/'passive_fit.json').read_text(encoding='utf-8'))
    x=np.load(out/'measurement.npz')['pre']
    v,y=x.T
    def predict(p,voltage):
        z=(voltage/np.exp(p[1]))**p[2]
        return np.exp(p[0])*z/(1+z)+np.exp(p[3])*voltage
    mask=np.arange(len(v))%2==0
    def solve(selected):
        return least_squares(lambda p:np.log10(predict(p,v[selected]))-np.log10(y[selected]),
              [-14.4,-.5,3.,-16.4],bounds=([-25,-5,.2,-30],[-3,3,6,-8]),
              loss='soft_l1',f_scale=.2,max_nfev=2000)
    p=solve(np.ones(len(v),bool)).x
    cv=solve(mask).x
    err=np.log10(predict(p,v)/y)
    row=dict(model='ohmic_saturating_power',parameters=p.tolist(),
        log10_rmse=float(np.sqrt(np.mean(err**2))),
        interleaved_holdout_log10_rmse=float(np.sqrt(np.mean(np.log10(predict(cv,v[~mask])/y[~mask])**2))),
        bic=float(len(v)*np.log(np.mean(err**2))+4*np.log(len(v))))
    candidates=[r for r in meta['candidates'] if r['model']!='ohmic_saturating_power']+[row]
    meta.update(candidates=candidates,chosen_leakage=min(candidates,key=lambda r:r['bic']),
                seed_training=[7,17,27],seed_validation=[37,47,57])
    write_json(out/'passive_fit.json',meta)
    print(json.dumps(candidates,indent=2))


def collect_trials(out):
    out=out.resolve()
    groups={}
    for p in sorted((out/'scout').glob('*/*/summary.json')):
        s=json.loads(p.read_text(encoding='utf-8'));cfg=s['config']
        key=json.dumps({k:v for k,v in cfg.items() if k not in ['seed']},sort_keys=True)
        groups.setdefault(key,[]).append(dict(path=p.parent.relative_to(ROOT).as_posix(),**s))
    meta=json.loads((out/'passive_fit.json').read_text(encoding='utf-8'))
    low,high=meta['forming_bracket_V']
    table=[]
    for cfg, runs in groups.items():
        # A repeated run with a larger budget/config forms its own group.
        if {r['config']['seed'] for r in runs}!={7,17,27} or len(runs)!=3:continue
        vv=[r['bridge']['voltage_V'] if r['bridge'] else None for r in runs]
        censored=sum(r['status']=='event_budget_unknown' for r in runs)
        missing=sum(v is None for v in vv)
        errors=[max(low-v,0,v-high) for v in vv if v is not None]
        score=float(np.sqrt(np.mean(np.square(errors)))) if errors and not missing else None
        table.append(dict(config=json.loads(cfg),paths=[r['path'] for r in runs],
                          seed_voltages={str(r['config']['seed']):v for r,v in zip(runs,vv)},
                          missing=missing,numerically_censored=censored,
                          bracket_rmse_V=score,
                          median_forming_V=float(np.median(vv)) if not missing else None))
    return table


def select(out):
    meta=json.loads((out/'passive_fit.json').read_text(encoding='utf-8'))
    table=collect_trials(out)
    eligible=[r for r in table if r['missing']==0]
    if not eligible:raise RuntimeError('No complete three-seed candidate; finish/refine the search')
    chosen=min(eligible,key=lambda r:(r['bracket_rmse_V'],abs(r['median_forming_V']-np.mean(meta['forming_bracket_V']))))
    config=dict(chosen['config'],seed=7,max_time_s=2.02)
    leakage=meta['chosen_leakage'];p=leakage['parameters']
    params=asdict(ElectronicConfig(series_resistance_ohm=0.))
    params.update(leakage_model=leakage['model'],leakage_saturation_A=float(np.exp(p[0])),
                  leakage_half_voltage_V=float(np.exp(p[1])),leakage_exponent=float(p[2]),
                  compliance_A=meta['compliance_A'])
    if leakage['model']=='ohmic_saturating_power':
        params['leakage_per_column_S']=float(np.exp(p[3])/config['nx'])
    conductances=[]
    for folder in chosen['paths']:
        state=np.load(ROOT/folder/'states.npz')['state']
        conductances.append(electronic_network(state,config['spacing_nm'],ElectronicConfig(**params))['conductance_S'])
    low=np.asarray(meta['return_fit_points'])
    # One shared scale for every seed, fitted in log-current, not one value per trajectory.
    def residual(p):
        factor=float(np.exp(p[0]))
        return np.concatenate([np.log10((g*factor*low[:,0]+np.asarray([
            leakage_current(v,config['nx'],ElectronicConfig(**params)) for v in low[:,0]]))/low[:,1]) for g in conductances])
    sol=least_squares(residual,[np.log(meta['return_conductance_S']/np.exp(np.mean(np.log(conductances))))])
    params['network_parallel_factor']=float(np.exp(sol.x[0]))
    name='configs/forming_fitted_model_20261109.json'
    settings=dict(model_config=name,electronics=params,event_catalogue='cached_exact',
        protocol=[dict(voltage_V=float(v),duration_s=.01) for v in np.load(out/'measurement.npz')['values'][:,0]],
        allow_frozen_return=True,measurement_reference=meta['source'],timing_note=meta['timing_note'],
        calibration_status='single_trace_ensemble_refit',training_seeds=[7,17,27],
        validation_seeds=[37,47,57],vacancy_parameters='fixed sensitivity assumption, not identified by this curve',
        identifiability_note='One effective parameter set conditional on the model and 10 ms point duration')
    write_json(ROOT/name,config)
    write_json(ROOT/'configs/forming_iv_fitted_20261109.json',settings)
    write_json(out/'trial_selection.json',table)
    write_json(out/'selected_candidate.json',dict(chosen=chosen,shared_network_parallel_factor=params['network_parallel_factor'],
        bare_network_conductances_S=conductances,return_fit_log10_rmse=float(np.sqrt(np.mean(sol.fun**2))),
        model_config=name,settings_config='configs/forming_iv_fitted_20261109.json',
        status='parameters_frozen_before_reserved_seed_runs'))
    print(json.dumps(chosen,indent=2))


def report(out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from run import panel
    from kmc_model import Config
    meta=json.loads((out/'passive_fit.json').read_text(encoding='utf-8'))
    selected=json.loads((out/'selected_candidate.json').read_text(encoding='utf-8'))
    cfg=json.loads((ROOT/'configs/forming_iv_fitted_20261109.json').read_text())
    measurement=np.load(out/'measurement.npz')
    data,up,down=measurement['values'],measurement['up'],measurement['down']
    source,_,fresh,_,_,jump,source_rows=load_measurement()
    assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['sha256']
    np.testing.assert_array_equal(fresh,data)
    lower,upper=meta['forming_bracket_V']
    runs=[];scans={};summaries={}
    for folder in sorted((out/'coupled').glob('*/*')):
        if not (folder/'summary.json').exists():continue
        summary=json.loads((folder/'summary.json').read_text(encoding='utf-8'))[0]
        seed=summary['config']['seed'];role=summary['role']
        name=f'{role}_seed_{seed}'
        records=json.loads((folder/f'assist_seed_{seed}.scan.json').read_text())
        predicted=np.asarray([r['current_A'] for r in records])
        bridge=summary['first_bridge'];voltage=bridge['command_voltage_V'] if bridge else None
        def rmse(indices):
            indices=np.asarray(indices);indices=indices[indices<len(records)]
            indices=indices[(data[indices,0]>0)&(data[indices,1]>0)]
            if not len(indices):return None
            return float(np.sqrt(np.mean(np.log10(np.maximum(predicted[indices],1e-30)/data[indices,1])**2)))
        positive_return=np.arange(len(up),len(data))
        unlim_return=positive_return[(data[positive_return,0]>0)&(data[positive_return,1]<meta['compliance_A']*.98)]
        g=records[-1]['network_conductance_S']
        row=dict(name=name,seed=seed,role=role,path=folder.relative_to(ROOT).as_posix(),
            status=summary['status'],forming_voltage_V=voltage,
            forming_distance_to_bracket_V=max(lower-voltage,0,voltage-upper) if bridge else None,
            preforming_log10_rmse=rmse(np.arange(1,jump)),outbound_log10_rmse=rmse(np.arange(len(up))),
            return_log10_rmse=rmse(positive_return),unlimited_return_log10_rmse=rmse(unlim_return),
            predicted_low_state_ohm=1/g if bridge else None,events=summary['events'],
            recorded_points=len(records),ag_balance_error=summary['ag_balance_error'],
            metal_only_fraction_at_bridge=summary.get('metal_only_fraction_at_bridge'),
            scout_exact_match=None)
        if role=='training':
            pilot=next(ROOT/p for p in selected['chosen']['paths'] if json.loads((ROOT/p/'config.json').read_text())['seed']==seed)
            scout=json.loads((pilot/'summary.json').read_text())
            with np.load(folder/f'assist_seed_{seed}.npz') as a,np.load(pilot/'states.npz') as b:
                match=(bridge is not None and bridge['events']==scout['bridge']['events'] and
                       np.array_equal(a['scan_states'][-1],b['state']))
            row['scout_exact_match']=bool(match)
        runs.append(row);scans[name]=predicted;summaries[name]=summary
    if not runs:raise RuntimeError('No circuit-coupled results')
    by_role={}
    for role in sorted({r['role'] for r in runs}):
        rr=[r for r in runs if r['role']==role]
        vv=[r['forming_voltage_V'] for r in rr if r['forming_voltage_V'] is not None]
        complete=[scans[r['name']] for r in rr if len(scans[r['name']])==len(data)]
        median_curve=np.median(complete,axis=0) if complete else None
        median_outward_error=(np.log10(np.maximum(median_curve[1:len(up)],1e-30)/up[1:,1])
                              if median_curve is not None else None)
        resistances=[r['predicted_low_state_ohm'] for r in rr if r['predicted_low_state_ohm'] is not None]
        by_role[role]=dict(count=len(rr),formed=len(vv),
            median_forming_V=float(np.median(vv)) if vv else None,
            mean_forming_V=float(np.mean(vv)) if vv else None,
            forming_min_max_V=[float(min(vv)),float(max(vv))] if vv else None,
            forming_std_V=float(np.std(vv,ddof=1)) if len(vv)>1 else None,
            median_inside_measured_bracket=bool(vv and lower-1e-12<=np.median(vv)<=upper+1e-12),
            fraction_within_one_voltage_step=float(np.mean([r['forming_distance_to_bracket_V'] is not None and
                            r['forming_distance_to_bracket_V']<=.015+1e-12 for r in rr])),
            median_curve_outbound_log10_rmse=(float(np.sqrt(np.mean(median_outward_error**2)))
                                             if median_outward_error is not None else None),
            median_low_state_ohm=float(np.median(resistances)) if resistances else None,
            low_state_min_max_ohm=[float(min(resistances)),float(max(resistances))] if resistances else None,
            mean_outbound_log10_rmse=float(np.mean([r['outbound_log10_rmse'] for r in rr])))
    expected={('training',7),('training',17),('training',27),
              ('reserved_seed',37),('reserved_seed',47),('reserved_seed',57)}
    workflow_done=expected.issubset({(r['role'],r['seed']) for r in runs})
    unfinished=[]
    for p in sorted((out/'scout').glob('*/*/config.json')):
        if not (p.parent/'summary.json').exists():
            progress=p.parent/'progress.json'
            unfinished.append(dict(path=p.parent.relative_to(ROOT).as_posix(),
                last_progress=json.loads(progress.read_text()) if progress.exists() else None,
                status='interrupted_no_completed_summary',included_in_selection=False))
    write_json(out/'interrupted_runs.json',unfinished)
    result=dict(measurement_sha256=meta['sha256'],point_duration_s=.01,forming_bracket_V=[lower,upper],
        passive_models=meta['candidates'],chosen_passive_model=meta['chosen_leakage'],
        target_low_state_ohm=meta['return_resistance_ohm'],roles=by_role,runs=runs,
        selection=selected,workflow_completed=workflow_done,interrupted_runs_excluded=len(unfinished),
        limitations=['Single measured trace; reserved seeds are simulation checks, not independent experiments',
                     'Vacancy fraction and penalty were fixed; their microscopic values are not identified',
                     'Nonmonotonic preforming dip is retained in residuals and not explicitly modeled',
                     'Postbridge geometry is frozen; no growth, RESET, heating or instrument integration model'])
    write_json(out/'fit_metrics.json',result)
    from importlib.metadata import version
    import platform
    write_json(out/'environment.json',dict(python=sys.version,platform=platform.platform(),
        dependencies={name:version(name) for name in ['numpy','scipy','matplotlib']}))
    names=[r['name'] for r in runs]
    with (out/'measured_vs_fitted.csv').open('w',newline='',encoding='utf-8-sig') as f:
        columns=['point_index','source_csv_row','branch','command_voltage_V','measured_current_A','nominal_end_s']+names
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
        for j,(v,i) in enumerate(data):
            row=dict(point_index=j,source_csv_row=source_rows[j],branch='outbound' if j<len(up) else 'return',
                     command_voltage_V=v,measured_current_A=i,nominal_end_s=(j+1)*.01)
            row.update({name:scans[name][j] if j<len(scans[name]) else '' for name in names})
            writer.writerow(row)
    fig,axes=plt.subplots(2,2,figsize=(12,9),layout='constrained')
    axes[0,0].semilogy(up[1:,0],up[1:,1],'ko',ms=3,label='Measured outward')
    axes[0,1].plot(down[:,0],down[:,1]*1e3,'ko',ms=3,label='Measured return')
    colors={'training':'#2878b5','reserved_seed':'#d65f21','new_defect_maps':'#34916e'}
    for role,color in colors.items():
        role_names=[r['name'] for r in runs if r['role']==role and len(scans[r['name']])==len(data)]
        if not role_names:continue
        values=np.asarray([scans[name] for name in role_names]);median=np.median(values,axis=0)
        axes[0,0].fill_between(up[1:,0],np.min(values[:,1:len(up)],axis=0),np.max(values[:,1:len(up)],axis=0),color=color,alpha=.12)
        axes[0,0].semilogy(up[1:,0],median[1:len(up)],color=color,label=f'{role}: median / range')
        axes[0,1].plot(down[:,0],median[len(up):]*1e3,color=color,label=f'{role}: median')
    axes[0,0].axvspan(lower,upper,color='#d59b36',alpha=.25)
    pre=measurement['pre'];e=ElectronicConfig(**cfg['electronics'])
    axes[1,0].semilogy(pre[:,0],pre[:,1],'ko',ms=3,label='Measured, all preforming points')
    axes[1,0].semilogy(pre[:,0],[leakage_current(v,150,e) for v in pre[:,0]],color='#2878b5',label='Refitted passive branch')
    old=ElectronicConfig(**json.loads((ROOT/'configs/forming_iv_fitted_20261105.json').read_text())['electronics'])
    axes[1,0].semilogy(pre[:,0],[leakage_current(v,150,old) for v in pre[:,0]],'--',color='#999999',label='2026-11-05 passive fit')
    axes[1,1].axhspan(lower,upper,color='#d59b36',alpha=.25,label='Measured interval')
    stop_labels=set()
    for j,r in enumerate(runs):
        if r['forming_voltage_V'] is not None:
            axes[1,1].plot(j,r['forming_voltage_V'],'o',color=colors.get(r['role'],'gray'))
        else:
            if r['status']=='event_budget_unknown':
                label,marker,color='Event budget reached','+','gray'
            else:
                label,marker,color='No bridge by 1.50 V','x','red'
            axes[1,1].plot(j,1.50,marker,color=color,label=label if label not in stop_labels else None)
            stop_labels.add(label)
    axes[1,1].set_xticks(range(len(runs)),[f"{r['role']}\n{r['seed']}" for r in runs],rotation=35,ha='right',fontsize=7)
    axes[1,1].set_ylabel('First-bridge command voltage (V)')
    axes[1,1].legend(fontsize=8)
    for ax,title in zip(axes.ravel(),['Forming with fixed vacancy coupling','Positive return, frozen morphology',
                                     'Preforming residual includes the measured dip','Every circuit-coupled trajectory']):
        ax.set_title(title,fontsize=11);ax.grid(alpha=.2)
    for ax in axes.ravel()[:3]:ax.set_xlabel('Source command voltage (V)');ax.legend(fontsize=8)
    axes[0,0].set_ylabel('Current (A)');axes[0,1].set_ylabel('Current (mA)');axes[1,0].set_ylabel('Current (A)')
    fig.suptitle('Ag / AlN / AlScN / AlN / Pt | 10 ms per point | ensemble calibration')
    fig.savefig(out/'fit_comparison.png',dpi=180);fig.savefig(out/'fit_comparison.svg');plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,5),layout='constrained')
    ax.semilogy(up[1:,0],up[1:,1],'ko',ms=4,label='Measured')
    for r in runs:
        if r['role']=='new_defect_maps':continue
        values=scans[r['name']][:len(up)]
        ax.semilogy(up[1:len(values),0],values[1:],lw=1,alpha=.8,label=f"{r['role']} {r['seed']}")
    ax.axvspan(lower,upper,color='#d59b36',alpha=.2);ax.set(xlim=(1.1,1.5),ylim=(3e-8,2e-3),
        xlabel='Source command voltage (V)',ylabel='Current (A)',title='Forming transition: all trajectories')
    ax.grid(alpha=.2);ax.legend(fontsize=8);fig.savefig(out/'forming_transition.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(12,4.5),layout='constrained')
    for ax,r in zip(axes,[r for r in runs if r['role']=='training']):
        s=summaries[r['name']];folder=ROOT/r['path']
        state=np.load(folder/f'assist_seed_{r["seed"]}.npz')['scan_states'][-1]
        panel(ax,state,Config(**s['config']),f"Seed {r['seed']} | {r['forming_voltage_V']} V")
    fig.suptitle('Ag first-bridge morphologies | calibrated parameters with vacancy coupling')
    fig.savefig(out/'fitted_morphologies.png',dpi=180);plt.close(fig)
    role_text=[]
    for role,label in [('training','训练种子'),('reserved_seed','保留种子'),('new_defect_maps','更换无序与缺陷图')]:
        if role in by_role:
            r=by_role[role]
            desc=f"{label} {r['formed']}/{r['count']} 条成桥"
            if r['formed']:
                vmin,vmax=r['forming_min_max_V']
                desc+=f"，中位电压 {r['median_forming_V']:.3f} V，范围 {vmin:.3f}–{vmax:.3f} V"
            role_text.append(desc+'。')
    lines=['# 当前氮空位模型的 forming 实验曲线重拟合','',
        ' '.join(role_text),'',
        '本轮沿用原始 202 点 B1500A 记录、10 ms/点、0→1.5→0 V、1 mA 限流。Ag 金属细丝承担低阻导电，中层极化场与正向外加场同向。',
        '氮空位标记概率固定为 [0, 0.15, 0]，Ag⁺ 位点代价固定为 +0.05 eV，属于待实验约束的模型假设。三条训练轨迹共用无序图 811 和缺陷图 812。',
        '种子 7、17、27 共同参与参数选择。37、47、57 在参数冻结后运行，属于随机性检验。额外缺陷图检查同时更换宿主无序图和缺陷图。','',
        '## 结果','',
        f"实测跃迁区间为 {lower:.3f}–{upper:.3f} V，低压回扫两点给出等效电阻 {meta['return_resistance_ohm']:.3f} Ω。",
        f"形成前漏电模型选用 {meta['chosen_leakage']['model']}，对数电流 RMSE 为 {meta['chosen_leakage']['log10_rmse']:.4f}，同曲线交错留出误差为 {meta['chosen_leakage']['interleaved_holdout_log10_rmse']:.4f}。原拟合相应为 0.2392 和 0.2154。",'',
        '|用途|种子|成桥电压/V|距实测区间/V|上扫 log10 RMSE|回扫等效电阻/Ω|记录点数|',
        '|---|---:|---:|---:|---:|---:|---:|']
    for r in runs:
        lines.append(f"|{r['role']}|{r['seed']}|{r['forming_voltage_V']}|{r['forming_distance_to_bracket_V']}|{r['outbound_log10_rmse']:.4f}|{r['predicted_low_state_ohm']}|{r['recorded_points']}|")
    lines+=['','分组统计见 fit_metrics.json 的 roles 字段。图中阴影为本轮模拟种子的最小–最大范围，不是置信区间。',
        '![拟合比较](fit_comparison.png)','![跃迁细节](forming_transition.png)','![细丝形貌](fitted_morphologies.png)','',
        '## 参数与选择','',
        '每个候选使用相同三个训练种子，目标为成桥源电压到实测区间距离的均方根。未成桥和预算截断单独记录，参数选择仅接受三条完整成桥轨迹。',
        '低阻段采用三个训练首桥网络共用的并联权重，以两条未限流回扫点拟合。该权重代表未解析面外导电尺度，不能解释为测得的细丝根数。',
        '形成前增加 G·V 并联欧姆项，和原经验饱和支路相加。所有参数非负，零电压电流为零，保持单调负载线。BIC 和同曲线留出均用于比较复杂度。',
        f"最终源反应势垒 {selected['chosen']['config']['source_barrier_eV']} eV；AlN/AlScN 跳跃势垒 {selected['chosen']['config']['hop_aln_eV']}/{selected['chosen']['config']['hop_alscn_eV']} eV；裸 Pt 成核附加势垒 {selected['chosen']['config']['pt_nucleation_eV']} eV。",
        f"尝试频率 {selected['chosen']['config']['attempt_Hz']:.6g} Hz；共用网络倍率 {selected['shared_network_parallel_factor']:.6g}。完整参数在 ../../configs/forming_iv_fitted_20261109.json 及其 model_config。",'',
        '## 验证和边界','',
        '各 coupled 子目录的 verification.json 核对 Ag 守恒、限流、负载线、源码快照和成桥后冻结。训练搜索与电流耦合轨迹是否一致逐条保存在 fit_metrics.json。',
        '所有形成前正电压点均计入误差，包括 1.245–1.320 V 附近的下降和恢复。当前单调经验漏电不能解释这段非单调行为。',
        '零压点保留在 CSV，但不参与对数误差。1 mA 平台主要受仪器限流约束。回扫为首桥形貌冻结后的电子读出，未描述桥后加厚、热、RESET、仪器积分或瞬态。',
        '单条实验曲线提供条件有效参数，不能独立确定氮空位浓度、位点代价、绝对迁移势垒和三维电流尺度。随机种子检验不能替代新的器件测量。','',
        '## 复现','',
        '```powershell',
        "& ../ai4alscn/.venv/Scripts/python.exe run_forming.py --config configs/forming_iv_fitted_20261109.json --output results/new_refit_check --seeds 7,17,27,37,47,57",
        '```',
        '逐点实测/仿真数据见 measured_vs_fitted.csv；所有候选、配置和实际完成状态见 scout/ 与 trial_selection.json。',
        f'会话中断留下的 {len(unfinished)} 条未完成记录单列在 interrupted_runs.json，不参与候选选择，也不记作物理未成桥。重跑轨迹另存于带 restart 的批次。']
    (out/'拟合报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    files=['kmc_model.py','forming_iv.py','fast_kmc.py','run_forming.py','run.py','morphology_metrics.py',
        'scripts/refit_forming.py','scripts/report_forming_refit.py','scripts/verify_forming_refit.py','scripts/fit_forming.py','scripts/verify_forming.py',
        'configs/forming_iv_fitted_20261109.json','configs/forming_fitted_model_20261109.json','requirements.txt']
    files += [p.name for p in ROOT.glob('test_*.py')]+[source.relative_to(ROOT).as_posix()]
    write_json(out/'fit_source_manifest.json',{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in files})
    with zipfile.ZipFile(out/'fit_source_and_data.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in files:z.write(ROOT/name,name)
    print(json.dumps(by_role,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['passive','select','report'])
    parser.add_argument('--output',default='results/forming_refit_20261109')
    args=parser.parse_args();out=ROOT/args.output
    {'passive':passive_fit,'select':select,'report':report}[args.mode](out)
