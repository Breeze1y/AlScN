"""Recalibrate the vacancy-enabled model against the unchanged forming record.

Scouts are full KMC trajectories at the measured source voltage. A selected
ensemble must subsequently be rerun with event-wise electronic feedback.
"""
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
from fast_kmc import CachedModel, CachedFormingModel
from forming_iv import ElectronicConfig, electronic_network, run_forming
from kmc_model import Config
from scripts.fit_forming import prepare
from run_forming import save_csv


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def snapshot(folder):
    files = ['kmc_model.py', 'forming_iv.py', 'fast_kmc.py', 'run_forming.py',
             'run.py', 'morphology_metrics.py', 'scripts/refit_forming.py',
             'scripts/fit_forming.py', 'scripts/verify_forming.py', 'requirements.txt']
    files += [p.name for p in ROOT.glob('test_*.py')]
    manifest = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}
    write_json(folder / 'manifest.json', manifest)
    with zipfile.ZipFile(folder / 'source_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for name in files:
            archive.write(ROOT / name, name)
    return manifest


def scout(folder, config, voltages):
    folder.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    write_json(folder / 'config.json', asdict(config))
    m = CachedModel(config)
    records, states = [], []
    bridge = None
    for j, v in enumerate(voltages):
        m.set_voltage(float(v))
        result = m.advance((j + 1) * .01)
        records.append(dict(point=j, voltage_V=float(v), time_s=m.time, events=m.steps,
                            status=result['status'], metal=m.trace[-1]['metal'],
                            ions=m.trace[-1]['ions']))
        states.append(m.state.reshape(m.shape).copy())
        write_json(folder / 'progress.json', records[-1])
        if j % 20 == 0:
            print(folder.name, records[-1], flush=True)
        if m.connected:
            bridge = dict(voltage_V=float(v), time_s=m.time, events=m.steps)
            break
        if result['status'] == 'event_budget_unknown':
            break
    summary = dict(config=asdict(config), bridge=bridge, status=result['status'],
                   events=m.steps, time_s=m.time, wall_s=time.perf_counter()-started,
                   ag_balance_error=result['ag_balance_error'], counts=m.counts,
                   vacancy_affected_sites_by_layer=m.vacancy_affected_sites_by_layer.tolist(),
                   ion_residence_s=m.ion_residence_s.tolist(),
                   vacancy_ion_residence_s=m.vacancy_ion_residence_s.tolist(),
                   trace=m.trace,
                   scope='Kinetic scout; selected parameters require circuit-coupled validation')
    m.save_checkpoint(folder / 'checkpoint.npz')
    np.savez_compressed(folder / 'states.npz', state=m.state.reshape(m.shape),
                        snapshots=np.asarray(m.snapshots), scan_states=np.asarray(states),
                        vacancy_mask=m.vacancy_mask.reshape(m.shape),
                        site_energy_eV=m.site.reshape(m.shape))
    write_json(folder / 'scan.json', records)
    write_json(folder / 'summary.json', summary)
    print(folder.name, 'finished', bridge, f'{summary["wall_s"]:.1f} s', flush=True)
    return dict(folder=str(folder.relative_to(ROOT)), **summary)


def coupled(folder, config, electronics, protocol, role):
    folder.mkdir(parents=True, exist_ok=False)
    snapshot(folder)
    started = time.perf_counter()
    def progress(i, m, status):
        write_json(folder / 'progress.json', dict(segment=i, voltage_V=m.command_voltage,
                   time_s=m.time, events=m.steps, status=status))
        if i % 20 == 0:
            print(folder.name, i, m.command_voltage, m.steps, status, flush=True)
    m, summary, states, records = run_forming(config, electronics, protocol, progress,
                         allow_frozen_return=True, model_class=CachedFormingModel)
    summary.update(variant='assist', role=role, wall_s=time.perf_counter()-started,
                   calibration_status='single_trace_ensemble_refit', trace=m.trace)
    if summary['first_bridge']:
        first = next(row for row in m.iv if row['connected'])
        metal = electronic_network(states[-1], config.spacing_nm,
                                    replace(electronics, max_tunnel_gap_nm=0))
        summary['metal_only_fraction_at_bridge'] = (
            metal['conductance_S']*first['device_voltage_V']/first['current_A'])
    prefix = folder / f'assist_seed_{config.seed}'
    write_json(prefix.with_suffix('.json'), summary)
    write_json(prefix.with_suffix('.scan.json'), records)
    save_csv(prefix.with_suffix('.iv.csv'), m.iv)
    np.savez_compressed(prefix.with_suffix('.npz'), snapshots=np.asarray(m.snapshots),
                        snapshot_times_s=[r['time_s'] for r in m.trace],
                        snapshot_events=[r['events'] for r in m.trace], scan_states=states,
                        vacancy_mask=m.vacancy_mask.reshape(m.shape),
                        site_energy_eV=m.site.reshape(m.shape))
    write_json(folder / 'summary.json', [summary])
    print(folder.name, 'finished', summary['first_bridge'], flush=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'scout', 'coupled'])
    parser.add_argument('--output', default='results/forming_refit_20261109')
    parser.add_argument('--batch', default='initial')
    parser.add_argument('--barriers', type=float, nargs='+', default=[.68, .69, .70])
    parser.add_argument('--seeds', type=int, nargs='+', default=[7, 17, 27])
    parser.add_argument('--workers', type=int, default=6)
    parser.add_argument('--hop-shift', type=float, default=.10)
    parser.add_argument('--nucleation', type=float, default=.16)
    parser.add_argument('--attempt', type=float, default=1e13)
    parser.add_argument('--budget', type=int, default=2000000)
    parser.add_argument('--vacancy-seed', type=int, default=812)
    parser.add_argument('--disorder-seed', type=int, default=811)
    parser.add_argument('--penalty', type=float, default=.05)
    parser.add_argument('--config', default='configs/forming_iv_fitted_20261109.json')
    parser.add_argument('--role', default='training')
    args = parser.parse_args()
    out = ROOT / args.output
    if args.mode == 'prepare':
        prepare(out)
        write_json(out / 'design.json', dict(
            calibration_seeds=[7,17,27], reserved_event_seeds=[37,47,57],
            vacancy_fraction_by_layer=[0,.15,0], vacancy_penalty_eV=.05,
            fixed_polarization_C_m2=-.004, point_duration_s=.01,
            rationale='Fit kinetics conditional on fixed exploratory vacancy coupling; '
                      'one current record does not identify vacancy density and coupling separately.',
            objective='Equal weight by seed for distance of forming voltage to measured bracket; '
                      'report spread, non-forming and numerical censoring separately.',
            status='design_before_new_simulations'))
        snapshot(out)
        return
    batch = out / args.mode / args.batch
    batch.mkdir(parents=True, exist_ok=False)
    snapshot(batch)
    jobspec = []
    if args.mode == 'scout':
        base = Config(**json.loads((ROOT/'configs/baseline.json').read_text()))
        base = replace(base, voltage=0., max_events=args.budget, max_time_s=1.01,
                       attempt_Hz=args.attempt, hop_aln_eV=base.hop_aln_eV+args.hop_shift,
                       hop_alscn_eV=base.hop_alscn_eV+args.hop_shift,
                       pt_nucleation_eV=args.nucleation,
                       disorder_seed=args.disorder_seed, vacancy_seed=args.vacancy_seed,
                       vacancy_affected_fraction_by_layer=(0,.15,0),
                       vacancy_ag_ion_penalty_eV=args.penalty)
        voltages = np.load(out/'measurement.npz')['up'][:,0]
        for b in args.barriers:
            for seed in args.seeds:
                cfg = replace(base, source_barrier_eV=b, seed=seed)
                folder = batch/f'b{b:.5f}_s{seed}'
                jobspec.append((scout, (folder, cfg, voltages)))
    else:
        settings = json.loads((ROOT/args.config).read_text(encoding='utf-8'))
        base = Config(**json.loads((ROOT/settings['model_config']).read_text()))
        e = ElectronicConfig(**settings['electronics'])
        write_json(batch/'settings.json', settings)
        for seed in args.seeds:
            cfg = replace(base, seed=seed)
            if args.role == 'new_defect_maps':
                cfg = replace(cfg, vacancy_seed=args.vacancy_seed+seed,
                               disorder_seed=args.disorder_seed+seed)
            jobspec.append((coupled, (batch/f'seed_{seed}', cfg, e, settings['protocol'], args.role)))
    write_json(batch/'design.json', dict(arguments=vars(args), jobs=len(jobspec)))
    results = []
    with ProcessPoolExecutor(max_workers=min(args.workers,len(jobspec))) as pool:
        futures = [pool.submit(fn,*callargs) for fn,callargs in jobspec]
        for job in as_completed(futures):
            results.append(job.result())
            write_json(batch/'completed.json', results)
    write_json(batch/'complete.json', dict(completed=len(results), expected=len(jobspec)))


if __name__ == '__main__':
    main()
