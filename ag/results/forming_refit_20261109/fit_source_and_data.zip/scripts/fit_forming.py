"""Staged single-record calibration; every stochastic candidate is archived."""
from pathlib import Path
from dataclasses import asdict, replace
import argparse, csv, hashlib, json, sys, time
import numpy as np
from scipy.optimize import least_squares

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from kmc_model import Config, Model
from forming_iv import ElectronicConfig, electronic_network, circuit_point


def load_measurement():
    paths=list((ROOT/'forming_data').glob('*.csv'))
    if len(paths)!=1:raise ValueError('Select one forming record explicitly before multi-record fitting')
    p=paths[0];params={};header=None;points=[];raw_rows=[]
    for line,row in enumerate(csv.reader(p.open(encoding='utf-8-sig')),1):
        if not row:continue
        tag=row[0].strip()
        if tag=='TestParameter':params[row[1].strip()]=' | '.join(v.strip() for v in row[2:])
        elif tag=='DataName':header=[v.strip() for v in row[1:]]
        elif tag=='DataValue':
            if header is None:raise ValueError('DataValue before DataName')
            d=dict(zip(header,row[1:]));points.append([float(d['V1']),float(d['I1'])]);raw_rows.append(line)
    x=np.asarray(points)
    if not len(x) or not np.isfinite(x).all():raise ValueError('Invalid measurement')
    peak=int(np.argmax(x[:,0]));up=x[:peak+1];down=x[peak+1:]
    if not (np.all(np.diff(up[:,0])>=0) and np.all(np.diff(down[:,0])<=0)):raise ValueError('Unexpected sweep order')
    jumps=np.log10(np.maximum(up[1:,1],1e-30)/np.maximum(up[:-1,1],1e-30))
    jumps[up[1:,0]<.1]=-np.inf
    jump=int(np.argmax(jumps))+1
    return p,params,x,up,down,jump,raw_rows


def prepare(out):
    out.mkdir(parents=True,exist_ok=False)
    path,params,data,up,down,jump,rows=load_measurement()
    pre=up[1:jump];v,y=pre.T
    def evaluate(kind,p,voltage):
        if kind=='sinh':return np.exp(p[0])*np.exp(p[1])*np.sinh(voltage/np.exp(p[1]))
        z=(voltage/np.exp(p[1]))**p[2]
        return np.exp(p[0])*z/(1+z)
    candidates=[]
    for kind,guess,bounds in [('sinh',[-14.,0.],([-25.,-2.],[0.,6.])),
                               ('saturating_power',[-13.8,-.5,2.],([-25.,-5.,.2],[-3.,3.,6.]))]:
        def solve(mask):
            return least_squares(lambda p:np.log10(evaluate(kind,p,v[mask]))-np.log10(y[mask]),
                                 guess,bounds=bounds,loss='soft_l1',f_scale=.2,max_nfev=1500)
        train=np.arange(len(v))%2==0
        cv=solve(train)
        result=solve(np.ones(len(v),bool))
        residual=np.log10(evaluate(kind,result.x,v))-np.log10(y)
        candidates.append(dict(model=kind,parameters=result.x.tolist(),
            log10_rmse=float(np.sqrt(np.mean(residual**2))),
            interleaved_holdout_log10_rmse=float(np.sqrt(np.mean((np.log10(evaluate(kind,cv.x,v[~train]))-np.log10(y[~train]))**2))),
            bic=float(len(v)*np.log(np.mean(residual**2))+len(result.x)*np.log(len(v)))))
    chosen=min(candidates,key=lambda r:r['bic'])
    cc=float(params['Measurement.Primary.Compliance'])
    low=down[(down[:,0]>0)&(down[:,1]<cc*.98)]
    conductance=float(np.dot(low[:,0],low[:,1])/np.dot(low[:,0],low[:,0]))
    meta=dict(source=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        source_parameters=params,points=len(data),outbound_points=len(up),return_points=len(down),
        forming_bracket_V=up[jump-1:jump+1,0].tolist(),first_high_current_raw_row=rows[jump],
        compliance_A=cc,candidates=candidates,chosen_leakage=chosen,
        return_conductance_S=conductance,return_resistance_ohm=1/conductance,
        return_fit_points=low.tolist(),dwell_proxy_s=.01,
        timing_source='user_confirmation',timing_note='User corrected to 10 ms per point; nominal rate 1.5 V/s',
        seed_training=7,seed_validation=[17,27],
        model_selection_note='Holdout points are interleaved on the SAME record, not independent-device validation')
    (out/'passive_fit.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    np.savez_compressed(out/'measurement.npz',values=data,up=up,down=down,pre=pre)
    print(json.dumps(meta,indent=2))


def pilot(out,barrier,attempt,seed,budget,hop_shift,nucleation,cached,bond):
    base=Config(**json.loads((ROOT/'configs/baseline.json').read_text()))
    cfg=replace(base,source_barrier_eV=barrier,attempt_Hz=attempt,seed=seed,
                max_time_s=1.01,max_events=budget,hop_aln_eV=base.hop_aln_eV+hop_shift,
                hop_alscn_eV=base.hop_alscn_eV+hop_shift,pt_nucleation_eV=nucleation,bond_eV=bond,voltage=0.)
    label=f'b{barrier:.4f}_a{attempt:.5g}_h{hop_shift:.4f}_pt{nucleation:.3f}_bond{bond:.3f}_s{seed}_n{budget}'+('_cached' if cached else '')+'_10ms'
    folder=out/'pilots'/label;folder.mkdir(parents=True,exist_ok=False)
    (folder/'source_manifest.json').write_text(json.dumps({n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
        for n in ['kmc_model.py','scripts/fit_forming.py']},indent=2),encoding='utf-8')
    cls=Model
    if cached:
        from fast_kmc import CachedModel
        cls=CachedModel
    m=cls(cfg);records=[];start=time.perf_counter();bridge=None
    voltages=np.load(out/'measurement.npz')['up'][:,0]
    for j,v in enumerate(voltages):
        m.set_voltage(float(v));result=m.advance((j+1)*.01)
        records.append(dict(point=j,voltage_V=float(v),time_s=m.time,events=m.steps,
                            status=result['status'],metal=m.trace[-1]['metal'],ions=m.trace[-1]['ions']))
        (folder/'progress.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        if j%10==0 or result['status']!='protocol_complete_no_bridge':
            print(label,records[-1],flush=True)
        if m.connected:
            bridge=dict(voltage_V=float(v),time_s=m.time,events=m.steps);break
        if result['status']=='event_budget_unknown':break
    summary=dict(label=label,config=asdict(cfg),bridge=bridge,status=result['status'],
                 events=m.steps,time_s=m.time,ag_balance_error=result['ag_balance_error'],
                 wall_s=time.perf_counter()-start,counts=m.counts,
                 physics='Original KMC scout; passive electronic limit must be checked in coupled validation')
    (folder/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    m.save_checkpoint(folder/'checkpoint.npz')
    np.savez_compressed(folder/'states.npz',state=m.state.reshape(m.shape),snapshots=m.snapshots,
                        times_s=[r['time_s'] for r in m.trace],events=[r['events'] for r in m.trace])
    print(json.dumps(summary,indent=2),flush=True)


def select(out):
    passive=json.loads((out/'passive_fit.json').read_text())
    candidates=[]
    lower,upper=passive['forming_bracket_V']
    for path in (out/'pilots').glob('*/summary.json'):
        if not path.parent.name.endswith('_10ms'):continue
        s=json.loads(path.read_text())
        if s['config']['seed']!=7:continue
        bridge=s['bridge']
        error=max(lower-bridge['voltage_V'],0,bridge['voltage_V']-upper) if bridge else None
        candidates.append(dict(path=str(path.parent.relative_to(ROOT)),summary=s,
                               forming_voltage_error_V=error))
    completed=[c for c in candidates if c['summary']['bridge']]
    (out/'trial_selection.json').write_text(json.dumps(candidates,indent=2),encoding='utf-8')
    if completed:
        chosen=min(completed,key=lambda c:c['forming_voltage_error_V'])
    else:
        # Preserve a visible failed forward diagnostic rather than manufacture a bridge.
        usable=[c for c in candidates if c['summary']['status']=='protocol_complete_no_bridge']
        if not usable:raise RuntimeError('All candidates censored; no completed forward diagnostic')
        chosen=max(usable,key=lambda c:c['summary']['counts']['reduce']-c['summary']['counts']['oxidize'])
    folder=ROOT/chosen['path']
    config=chosen['summary']['config'];config['max_time_s']=2.02
    leakage=passive['chosen_leakage'];p=leakage['parameters']
    params=asdict(ElectronicConfig(series_resistance_ohm=0.))
    if leakage['model']=='saturating_power':
        params.update(leakage_model='saturating_power',leakage_saturation_A=float(np.exp(p[0])),
                      leakage_half_voltage_V=float(np.exp(p[1])),leakage_exponent=p[2])
    else:
        params.update(leakage_per_column_S=float(np.exp(p[0]))/config['nx'],
                      leakage_voltage_scale_V=float(np.exp(p[1])))
    state=np.load(folder/'states.npz')['state']
    g=electronic_network(state,config['spacing_nm'],ElectronicConfig(**params))['conductance_S']
    low=np.array(passive['return_fit_points'])
    def residual(logfactor):
        e=ElectronicConfig(**dict(params,network_parallel_factor=float(np.exp(logfactor[0]))))
        return np.array([circuit_point(v,g*e.network_parallel_factor,config['nx'],e)['current_A']/i-1 for v,i in low])
    if completed:
        fitted=least_squares(residual,[np.log(passive['return_conductance_S']/g)],bounds=([-15.],[15.]))
        params['network_parallel_factor']=float(np.exp(fitted.x[0]))
    measurement=np.load(out/'measurement.npz')['values']
    model_path='configs/forming_fitted_model_20261105.json'
    cfg=dict(model_config=model_path,electronics=params,event_catalogue='cached_exact',
        protocol=[dict(voltage_V=float(v),duration_s=.01) for v,i in measurement],
        allow_frozen_return=True,measurement_reference=passive['source'],
        timing_note=passive['timing_note'],calibration_status=('single_trace_candidate_not_independent_validation' if completed else 'partial_leakage_fit_kinetic_forming_not_matched'),
        training_seed=7,validation_seeds=[17,27],
        identifiability_note='Effective current-window multiplicity, not a measured filament count or unique physical parameter set')
    (ROOT/model_path).write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
    (ROOT/'configs/forming_iv_fitted_20261105.json').write_text(json.dumps(cfg,indent=2)+'\n',encoding='utf-8')
    result=dict(chosen=chosen['path'],forming_voltage_error_V=chosen['forming_voltage_error_V'],
                kinetic_fit_has_bridge=bool(completed),
                bare_network_conductance_S=g,network_parallel_factor=params['network_parallel_factor'],
                leakage=params,model_config=model_path,
                scope='Static fits and KMC scout only; coupled run and unseen-seed checks still required')
    (out/'selected_candidate.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


def resume(out,trial,budget):
    from fast_kmc import CachedModel
    previous=out/trial
    old=json.loads((previous/'summary.json').read_text())
    if old['status']!='event_budget_unknown':raise ValueError('Only a budget-censored trajectory can resume')
    if budget<=old['config']['max_events']:raise ValueError('Resume requires a larger numerical event budget')
    label=previous.name.replace(f"_n{old['config']['max_events']}_",f'_n{budget}_')
    folder=out/'pilots'/label;folder.mkdir(parents=True,exist_ok=False)
    m=CachedModel.load_checkpoint(previous/'checkpoint.npz')
    m.c=replace(m.c,max_events=budget)
    cfg=replace(Config(**old['config']),max_events=budget)
    records=json.loads((previous/'progress.json').read_text())[:-1]
    first=len(records);bridge=None;start=time.perf_counter()
    for j,v in enumerate(np.load(out/'measurement.npz')['up'][:,0]):
        if j<first:continue
        m.set_voltage(float(v));result=m.advance((j+1)*.01)
        records.append(dict(point=j,voltage_V=float(v),time_s=m.time,events=m.steps,
                            status=result['status'],metal=m.trace[-1]['metal'],ions=m.trace[-1]['ions']))
        (folder/'progress.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        if j%10==0 or result['status']!='protocol_complete_no_bridge':print(label,records[-1],flush=True)
        if m.connected:
            bridge=dict(voltage_V=float(v),time_s=m.time,events=m.steps);break
        if result['status']=='event_budget_unknown':break
    summary=dict(label=label,config=asdict(cfg),bridge=bridge,status=result['status'],events=m.steps,
                 time_s=m.time,ag_balance_error=result['ag_balance_error'],wall_s=time.perf_counter()-start,
                 counts=m.counts,resumed_from=str(previous.relative_to(ROOT)),
                 physics='Exact continuation with increased numerical budget; no kinetic parameter change')
    (folder/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    m.save_checkpoint(folder/'checkpoint.npz')
    np.savez_compressed(folder/'states.npz',state=m.state.reshape(m.shape),snapshots=m.snapshots,
                        times_s=[r['time_s'] for r in m.trace],events=[r['events'] for r in m.trace])
    print(json.dumps(summary,indent=2),flush=True)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['prepare','pilot','select','resume'])
    ap.add_argument('--output',default='results/forming_fit_20261105')
    ap.add_argument('--barrier',type=float,default=.74);ap.add_argument('--attempt',type=float,default=1e13)
    ap.add_argument('--seed',type=int,default=7);ap.add_argument('--budget',type=int,default=500000)
    ap.add_argument('--hop-shift',type=float,default=0.)
    ap.add_argument('--nucleation',type=float,default=.08)
    ap.add_argument('--bond',type=float,default=.06)
    ap.add_argument('--cached',action='store_true')
    ap.add_argument('--trial')
    a=ap.parse_args();out=ROOT/a.output
    if a.mode=='prepare':prepare(out)
    elif a.mode=='pilot':pilot(out,a.barrier,a.attempt,a.seed,a.budget,a.hop_shift,a.nucleation,a.cached,a.bond)
    elif a.mode=='select':select(out)
    else:resume(out,a.trial,a.budget)


if __name__=='__main__':main()
