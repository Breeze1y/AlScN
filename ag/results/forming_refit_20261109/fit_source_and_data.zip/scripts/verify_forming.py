"""Audit archived I-V data, topology, compliance and source snapshots."""
from pathlib import Path
import argparse, csv, hashlib, json, sys, zipfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from morphology_metrics import metrics


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',required=True);args=ap.parse_args()
    out=ROOT/args.results
    manifest=json.loads((out/'manifest.json').read_text())
    with zipfile.ZipFile(out/'source_snapshot.zip') as archive:
        for name,digest in manifest.items():
            assert hashlib.sha256(archive.read(name.replace('\\','/'))).hexdigest()==digest,name
    summaries=json.loads((out/'summary.json').read_text())
    checks=[]
    for s in summaries:
        prefix=out/f"{s['variant']}_seed_{s['config']['seed']}"
        rows=list(csv.DictReader(prefix.with_suffix('.iv.csv').open(encoding='utf-8-sig')))
        num=lambda key:np.array([float(r[key]) for r in rows])
        times,events,current,voltage,command=(num(k) for k in ['time_s','events','current_A','device_voltage_V','command_voltage_V'])
        limited=np.array([r['compliance_active']=='True' for r in rows])
        e=s['electronics'];tol=1e-11
        assert np.all(np.diff(times)>=-1e-14)
        assert np.all(np.diff(events)>=0)
        assert np.all(num('ag_balance_error')==0)
        assert np.all(np.isfinite(current)) and np.all(current>=0)
        assert np.all(current<=e['compliance_A']*(1+1e-10))
        np.testing.assert_allclose(current,num('network_current_A')+num('leakage_current_A'),atol=1e-15,rtol=1e-10)
        delivered=voltage+current*e['series_resistance_ohm']
        np.testing.assert_allclose(delivered,num('source_delivered_voltage_V'),atol=tol,rtol=1e-10)
        np.testing.assert_allclose(delivered[~limited],command[~limited],atol=tol,rtol=1e-10)
        np.testing.assert_allclose(current[limited],e['compliance_A'],atol=1e-14,rtol=1e-10)
        assert np.all(delivered[limited]<=command[limited]+tol)
        assert events[-1]==s['events']<=s['config']['max_events']
        assert s['counts']['inject']-s['counts']['absorb']==float(rows[-1]['net_source'])
        keyed={(float(r['time_s']),int(r['events'])):r for r in rows}
        with np.load(prefix.with_suffix('.npz'),allow_pickle=False) as data:
            snapshots=data['snapshots']
            assert len(snapshots)==len(data['snapshot_times_s'])==len(data['snapshot_events'])
            for state,t,n in zip(snapshots,data['snapshot_times_s'],data['snapshot_events']):
                r=keyed[(float(t),int(n))]
                assert np.all(state[[0,-1]]==2)
                assert np.count_nonzero(state[1:-1])==float(r['net_source'])
                assert np.sum(state[1:-1]==2)==float(r['metal'])
                assert np.sum(state[1:-1]==1)==float(r['ions'])
            final=metrics(data['scan_states'][-1],s['config']['spacing_nm'],s['config']['layer_cells'])
        assert final['connected_4']==bool(s['first_bridge'])
        if s['first_bridge']:
            first=next(i for i,r in enumerate(rows) if r['connected']=='True')
            assert int(events[first])==s['first_bridge']['events']
            assert np.all(events[first:]==events[first])
            assert np.all(num('metal')[first:]==num('metal')[first])
            assert np.all(num('ions')[first:]==num('ions')[first])
        if s['status']=='event_budget_unknown':
            assert events[-1]==s['config']['max_events']
            assert times[-1] < sum(x['duration_s'] for x in s['protocol'])
        elif s['status']=='return_not_read_no_bridge':
            assert not s['first_bridge']
            assert times[-1] < sum(x['duration_s'] for x in s['protocol'])
            assert np.isclose(command.max(),max(x['voltage_V'] for x in s['protocol']))
        else:
            assert abs(times[-1]-sum(x['duration_s'] for x in s['protocol']))<1e-12
        checks.append(dict(variant=s['variant'],seed=s['config']['seed'],rows=len(rows),
                           snapshots=len(snapshots),status=s['status'],
                           peak_current_A=float(current.max()),limited_samples=int(limited.sum()),
                           mass_balance_verified=True,load_line_verified=True,
                           post_bridge_frozen_verified=bool(s['first_bridge'])))
    result=dict(source_snapshot_verified=True,runs=checks,
                scope='Numerical integrity, not experimental calibration')
    (out/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
