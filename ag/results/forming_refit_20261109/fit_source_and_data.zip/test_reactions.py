"""Surface admissibility and contact-energy invariants of the local model."""
from dataclasses import replace
import unittest
import numpy as np
from kmc_model import Config,Model,KB


def rate(model,kind,a,b=-1):
    return sum(float(r) for k,aa,bb,rr in model.catalogue() if k==kind
               for x,y,r in zip(aa,bb,rr) if x==a and y==b)


class ReactionTests(unittest.TestCase):
    def test_vacancy_penalty_enters_all_ionic_forward_reverse_pairs(self):
        penalty = .05
        cfg = Config(nx=4, layer_cells=2, voltage=0, polarization_C_m2=0, disorder_eV=0,
                     vacancy_affected_fraction_by_layer=(1, 0, 1), vacancy_ag_ion_penalty_eV=penalty)
        model = Model(cfg)
        kT = KB * cfg.temperature_K
        source = cfg.nx + 1
        injection = rate(model, 'inject', source)
        model.state[source] = 1
        self.assertAlmostEqual(np.log(injection / rate(model, 'absorb', source)), -penalty / kT)
        model.state[source] = 0

        marked, unmarked = 2 * cfg.nx + 1, 3 * cfg.nx + 1
        model.state[marked] = 1
        out_of_defect = rate(model, 'hop', marked, unmarked)
        model.state[marked], model.state[unmarked] = 0, 1
        self.assertAlmostEqual(np.log(out_of_defect / rate(model, 'hop', unmarked, marked)), penalty / kT)
        model.state[unmarked] = 0

        contact = model.n - 2 * cfg.nx + 1
        model.state[contact] = 1
        reduction = rate(model, 'reduce', contact)
        model.state[contact] = 2
        model.update_structure()
        delta_g = cfg.metal_standard_eV - cfg.pt_adhesion_eV - penalty
        self.assertAlmostEqual(np.log(reduction / rate(model, 'oxidize', contact)), -delta_g / kT)

    def test_buried_redox_forbidden_in_both_directions(self):
        m=Model(Config(nx=5,layer_cells=2,voltage=0,polarization_C_m2=0))
        m.state.reshape(m.shape)[3:-1,1:4]=2;m.update_structure()
        a=5*m.c.nx+2
        self.assertEqual(rate(m,'oxidize',a),0)
        m.state[a]=1;m.update_structure()
        self.assertEqual(rate(m,'reduce',a),0)
        m.c=replace(m.c,surface_redox_only=False)
        self.assertGreater(rate(m,'reduce',a),0)

    def test_exposed_redox_pair_with_distinct_adhesion(self):
        m=Model(Config(nx=5,layer_cells=2,voltage=.3,polarization_C_m2=0,pt_adhesion_eV=.09))
        a=m.n-2*m.c.nx+2;m.state[a]=1
        phi=m.phi.copy()
        dg=m.c.metal_standard_eV-m.binding(np.array([a]))[0]-m.site[a]-phi[a]
        f=rate(m,'reduce',a)
        m.state[a]=2;m.update_structure();m.phi=phi
        r=rate(m,'oxidize',a)
        self.assertGreater(f,0);self.assertGreater(r,0)
        self.assertAlmostEqual(np.log(f/r),-dg/(KB*m.c.temperature_K),places=10)

    def test_migration_preserves_contact_energy_balance(self):
        m=Model(Config(nx=5,layer_cells=2,voltage=0,polarization_C_m2=0,pt_adhesion_eV=.10))
        a=m.n-2*m.c.nx+2;b=a-m.c.nx
        m.state[a]=2;m.update_structure();phi=m.phi.copy()
        dg=float(m.binding(np.array([a]))[0]-(m.binding(np.array([b]))[0]-m.c.bond_eV))
        f=rate(m,'migrate',a,b)
        m.state[a]=0;m.state[b]=2;m.update_structure();m.phi=phi
        r=rate(m,'migrate',b,a)
        self.assertAlmostEqual(np.log(f/r),-dg/(KB*m.c.temperature_K),places=10)


if __name__=='__main__':unittest.main()
