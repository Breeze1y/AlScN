"""Change only source exchange kinetics at the fixed J=.10, nu=2.65e12 control."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import argparse,copy,hashlib,json,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'results/opening_calibration_20261113'))
from run_kmc import write_json
import calibration_driver as runner

def trial(barrier,seed):
    runner.BASE=json.loads((HERE/'baseline_settings.json').read_text(encoding='utf-8'))
    runner.BASE['model'].update(bond_eV=.10,source_barrier_eV=barrier)
    runner.OUT=HERE/f'source_{barrier:.3f}_J0.100';runner.OUT.mkdir(exist_ok=True)
    result=runner.trial(2.65e12,seed)
    folder=Path(result['folder']);audit=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    settings=audit['configuration']
    if 'calibration' in settings:settings['previous_calibration']=settings.pop('calibration')
    settings['solver_revision']='local_electron_reservoir_20261116'
    settings['parameter_status']='Source-exchange sensitivity at J=.10 eV and nu=2.65e12 Hz; not a completed fit'
    audit.update(experiment='Fixed cohesive control; only common inject/absorb barrier changed from 0.680 eV',
        experiment_driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write_json(folder/'manifest.json',audit);write_json(folder/'trial_config.json',settings)
    print('SOURCE_TRIAL_COMPLETE',barrier,seed,result['first_bridge_voltage_V'],flush=True)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--barriers',type=float,nargs='+',default=[.679,.678,.677])
    parser.add_argument('--seeds',type=int,nargs='+',default=[17]);parser.add_argument('--workers',type=int,default=3)
    args=parser.parse_args();jobs=[(b,s) for b in args.barriers for s in args.seeds]
    with ProcessPoolExecutor(max_workers=min(args.workers,len(jobs))) as pool:
        futures=[pool.submit(trial,*job) for job in jobs]
        results=[future.result() for future in as_completed(futures)]
    write_json(HERE/'source_scan_summary.json',results)
