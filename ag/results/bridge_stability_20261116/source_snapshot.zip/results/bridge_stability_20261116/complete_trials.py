"""Continue new scout checkpoints through a fixed 200 ms zero-bias hold."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import argparse,copy,hashlib,json,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(HERE))
from run_kmc import run_dynamic,write_json
from evaluate import assess

def complete(folder):
    folder=Path(folder).resolve()
    audit=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    if (folder/'result.json').exists():
        result=json.loads((folder/'result.json').read_text(encoding='utf-8'))
        if result['status']=='loop_and_zero_hold_complete':
            if abs(result['zero_hold_s']-.2)>1e-10:
                raise ValueError('Preserve earlier short-hold result; extend in a distinct output folder')
            return assess(folder)[0]
    if not (folder/'pre_full_loop_protocol.json').exists():
        write_json(folder/'pre_full_loop_protocol.json',audit['configuration'])
    settings=copy.deepcopy(audit['configuration'])
    if 'calibration' in settings:settings['previous_calibration']=settings.pop('calibration')
    settings['solver_revision']='local_electron_reservoir_20261116'
    settings['parameter_status']='Unselected local-reservoir / cohesion / kinetic-clock trial; assess the full loop independently'
    settings['protocol']['settling']={'min_s':.2,'max_s':.2,'window_s':.02}
    settings['validation_scope']='Fresh first-bridge scout continued with exact RNG and pending event; fixed 200 ms zero-bias comparison'
    audit['configuration']=settings
    audit['completion_driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    audit['protocol_change']='Zero-bias hold fixed to 200 ms before full-loop validation; voltage points, dwell, KMC state and rates unchanged'
    write_json(folder/'trial_config.json',settings)
    args=argparse.Namespace(max_events=20000000,max_wall_s=1800)
    result=run_dynamic(args,settings,folder,audit,resume=True)
    if result['status']!='loop_and_zero_hold_complete':
        return dict(folder=str(folder),status=result['status'])
    a=assess(folder)[0]
    print('FULL_COMPLETE',folder.name,'J',a['bond_eV'],'endpoint',a['first_endpoint_opening_V'],
          'ruptures',a['geometric_ruptures'],'zero_stable',a['continuous_filament_stable'],flush=True)
    return a

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--folder',type=Path,nargs='+',required=True)
    parser.add_argument('--workers',type=int,default=3);args=parser.parse_args()
    with ProcessPoolExecutor(max_workers=min(args.workers,len(args.folder))) as pool:
        futures=[pool.submit(complete,folder) for folder in args.folder]
        for future in as_completed(futures):
            a=future.result()
            print(json.dumps({k:a[k] for k in ('folder','seed','attempt_Hz','bond_eV','first_endpoint_opening_V',
                'inclusive_window_pass','exact_experimental_bin_pass','endpoint_up_plateau_retained',
                'geometric_ruptures','continuous_filament_stable') if k in a}),flush=True)
